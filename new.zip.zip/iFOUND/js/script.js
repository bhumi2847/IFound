const page = location.pathname.split('/').pop();

const demoLost = [
  {id:10,type:'lost',name:'Water Bottle',category:'Other',date:'2026-09-04',location:'Lecture Hall',description:'Dark reusable water bottle left in a lecture hall.',contact:'9876543215',image:'assets/images/water-bottle.svg',user:'demo'},
  {id:1,type:'lost',name:'Backpack',category:'Clothing',date:'2026-09-05',location:'Cafeteria',description:'Blue and black backpack reported missing near the cafeteria.',contact:'9876543210',image:'assets/images/backpack-ref.jpg',user:'demo'},
  {id:2,type:'lost',name:'Notebook',category:'Books',date:'2026-09-07',location:'Library',description:'Spiral notebook with a black pen.',contact:'9876543211',image:'assets/images/notebook-user.jpg',user:'demo'},
  {id:3,type:'lost',name:'Laptop',category:'Electronics',date:'2026-09-09',location:'Block A',description:'Silver laptop reported missing from campus.',contact:'9876543212',image:'assets/images/laptop-ref.jpg',user:'demo'},
  {id:4,type:'lost',name:'Student ID',category:'Documents',date:'2026-09-10',location:'Academic Block',description:'College student ID card reported missing.',contact:'9876543213',image:'assets/images/student-id-ref.jpg',user:'demo'},
  {id:5,type:'lost',name:'Glasses',category:'Accessories',date:'2026-09-11',location:'Sports Complex',description:'Black framed glasses reported missing.',contact:'9876543214',image:'assets/images/glasses-ref.jpg',user:'demo'},
  {id:11,type:'lost',name:'Scientific Calculator',category:'Electronics',date:'2026-09-12',location:'Lab 2',description:'Black scientific calculator reported missing from the lab.',contact:'9876543216',image:'assets/images/calculator-user.jpg',user:'demo'}
];

const demoFound = [
  {id:6,type:'found',name:'Watch',category:'Accessories',date:'2026-09-06',location:'Library',description:'Black wrist watch found on campus.',contact:'9876543220',image:'assets/images/watch-ref.jpg',user:'demo'},
  {id:7,type:'found',name:'Keys',category:'Other',date:'2026-09-08',location:'Main Gate',description:'A set of keys found near the main gate.',contact:'9876543221',image:'assets/images/keys-user.jpg',user:'demo'},
  {id:8,type:'found',name:'Calculator',category:'Electronics',date:'2026-09-10',location:'Lab 2',description:'Scientific calculator found in the lab.',contact:'9876543222',image:'assets/images/calculator-user.jpg',user:'demo'},
  {id:9,type:'found',name:'Earphones',category:'Electronics',date:'2026-09-11',location:'Library',description:'White wired earphones found near the library.',contact:'9876543223',image:'assets/images/earphones-user.jpg',user:'demo'},
  {id:12,type:'found',name:'USB Drive',category:'Electronics',date:'2026-09-12',location:'Computer Lab',description:'Silver and black USB flash drive found in the computer lab.',contact:'9876543224',image:'assets/images/usb-drive-user.jpg',user:'demo'}
];

function addDemoItems(key, demos) {
  let items = JSON.parse(localStorage.getItem(key)) || [];
  demos.forEach(demo => {
    let i = items.findIndex(item => item.id === demo.id);
    if (i === -1) items.push(demo);
    else if (items[i].user === 'demo') items[i] = demo;
  });
  localStorage.setItem(key, JSON.stringify(items));
}

addDemoItems('lostItems', demoLost);
addDemoItems('foundItems', demoFound);

function $(id) { return document.getElementById(id); }
function logged() { return localStorage.getItem('loggedIn') === 'true'; }

if (['lost.html','found.html','report-lost.html','report-found.html','profile.html'].includes(page) && !logged()) {
  location.href = 'login.html';
}

const menu = document.querySelector('.menu');
const nav = document.querySelector('.nav');

if (menu) menu.onclick = () => nav.classList.toggle('open');
if (nav && page !== 'index.html') {
  if (logged()) {
    const signout = document.createElement('a');
    signout.href = '#'; signout.textContent = 'Sign out';
    signout.onclick = e => { e.preventDefault(); localStorage.removeItem('loggedIn'); localStorage.removeItem('username'); location.href = 'index.html'; };
    nav.appendChild(signout);
  } else {
    const signin = document.createElement('a'); signin.href = 'login.html'; signin.textContent = 'Sign in'; nav.appendChild(signin);
    const signup = document.createElement('a'); signup.href = 'signup.html'; signup.textContent = 'Sign up'; nav.appendChild(signup);
  }
}




const loading = document.querySelector('.loading');
if (loading) setTimeout(() => loading.style.display = 'none', 1600);

if ($('loginForm')) {
  $('loginForm').onsubmit = e => {
    e.preventDefault();
    const u = $('loginUser').value.trim();
    const p = $('loginPass').value;
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    const legacyUser = JSON.parse(localStorage.getItem('user') || 'null');
    const allUsers = legacyUser && !users.some(x => x.username === legacyUser.username) ? [...users, legacyUser] : users;
    const matched = allUsers.find(x => x.username.toLowerCase() === u.toLowerCase() && x.password === p);
    if (!u || !p) {
      $('loginError').textContent = 'Enter your username and password.';
      return;
    }
    if (!matched) {
      $('loginError').textContent = 'Account not found or password is incorrect. Please sign up if you are new.';
      return;
    }
    localStorage.setItem('loggedIn', 'true');
    localStorage.setItem('username', matched.username);
    localStorage.setItem('user', JSON.stringify(matched));
    location.href = 'index.html';
  };
}

if ($('signupForm')) {
  $('signupForm').onsubmit = e => {
    e.preventDefault();
    const user = {
      name:$('name').value.trim(), gender:$('gender').value,
      reg:$('reg').value.trim(), faculty:$('faculty').value,
      phone:$('phone').value.trim(), username:$('username').value.trim(),
      password:$('password').value
    };
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    if (!user.name || !user.reg || !user.phone || !user.username || !user.password) {
      $('signupMsg').textContent = 'Please fill in every required field.'; return;
    }
    if (!/^\d{10}$/.test(user.phone)) {
      $('signupMsg').textContent = 'Enter a valid 10-digit phone number.'; return;
    }
    if (user.username.length < 3) {
      $('signupMsg').textContent = 'Username must contain at least 3 characters.'; return;
    }
    if (user.password.length < 6) {
      $('signupMsg').textContent = 'Password must be at least 6 characters.'; return;
    }
    if (users.some(x => x.username.toLowerCase() === user.username.toLowerCase())) {
      $('signupMsg').textContent = 'That username is already registered. Please sign in.'; return;
    }
    users.push(user);
    localStorage.setItem('users', JSON.stringify(users));
    localStorage.setItem('user', JSON.stringify(user));
    $('signupMsg').className = 'success';
    $('signupMsg').textContent = 'Account created! Taking you to sign in…';
    setTimeout(() => location.href = 'login.html', 900);
  };
}

function forgotPassword() {
  const username = prompt('Enter the username for the account you want to reset:');
  if (!username) return;
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  const index = users.findIndex(x => x.username.toLowerCase() === username.trim().toLowerCase());
  if (index < 0) { alert('No registered account found with that username.'); return; }
  const next = prompt('Demo reset: enter a new password (at least 6 characters).');
  if (!next || next.length < 6) { alert('Password was not changed. Use at least 6 characters.'); return; }
  users[index].password = next;
  localStorage.setItem('users', JSON.stringify(users));
  alert('Password updated on this browser. Please sign in again.');
}

function showItems(type) {
  let list = JSON.parse(localStorage.getItem(type + 'Items')) || [];
  let q = ($('search').value || '').toLowerCase();
  let cat = $('category').value;
  let box = $('items');
  let result = list.filter(x =>
    (x.name + ' ' + x.category + ' ' + x.location + ' ' + x.description).toLowerCase().includes(q) &&
    (cat === 'All' || x.category === cat)
  );

  box.innerHTML = '';
  if (!result.length) {
    box.innerHTML = '<div class="empty">No matching items found.</div>';
    return;
  }

  result.forEach(x => {
    box.innerHTML += `<article class="card">
      <img src="${x.image}" alt="${x.name}" loading="lazy" onerror="this.onerror=null;this.src=makeItemImage(this.alt,'')">
      <div class="card-body">
        <h3>${x.name}</h3>
        <p>${x.category}</p>
        <p>${x.location}</p>
        <p>${x.date}</p>
        <span class="status ${x.type === 'found' ? 'found' : ''}">${x.type}</span>
        <a class="details-btn" href="item-details.html?id=${x.id}&type=${x.type}">View Details</a>
      </div>
    </article>`;
  });
}

if ($('items')) {
  let type = page === 'lost.html' ? 'lost' : 'found';
  showItems(type);
  $('search').oninput = () => showItems(type);
  $('category').onchange = () => showItems(type);
  $('searchBtn').onclick = () => showItems(type);
}

function saveReport(type) {
  const file = $('itemImage').files[0];
  const finish = image => {
    let arr = JSON.parse(localStorage.getItem(type + 'Items')) || [];
    let item = {
      id:Date.now(),
      type:type,
      name:$('itemName').value.trim(),
      category:$('itemCategory').value,
      date:$('itemDate').value,
      location:$('itemLocation').value.trim(),
      description:$('itemDescription').value.trim() + ' ' + $('itemExtra').value.trim(),
      contact:$('itemContact').value.trim(),
      image:image || makeItemImage($('itemName').value.trim(), $('itemCategory').value),
      user:localStorage.getItem('username')
    };
    arr.push(item);
    localStorage.setItem(type + 'Items', JSON.stringify(arr));
    $('formMsg').textContent = type === 'lost' ? 'Lost item reported successfully!' : 'Found item reported successfully!';
    setTimeout(() => location.href = type === 'lost' ? 'lost.html' : 'found.html', 700);
  };

  if (file) {
    let r = new FileReader();
    r.onload = () => finish(r.result);
    r.readAsDataURL(file);
  } else {
    finish();
  }
}

if ($('lostForm')) $('lostForm').onsubmit = e => { e.preventDefault(); saveReport('lost'); };
if ($('foundForm')) $('foundForm').onsubmit = e => { e.preventDefault(); saveReport('found'); };

if ($('profileBox')) {
  let u = JSON.parse(localStorage.getItem('user')) || {};
  let name = u.name || localStorage.getItem('username') || 'Student';
  let initials = name.split(' ').map(x => x[0]).join('').slice(0, 2).toUpperCase();

  $('profileBox').innerHTML = `<div class="profile-avatar">${initials}</div>
    <h2>${name}</h2>
    <div class="profile-details">
      <div class="profile-detail"><small>Gender</small><b>${u.gender || 'Not available'}</b></div>
      <div class="profile-detail"><small>Register Number</small><b>${u.reg || 'Not available'}</b></div>
      <div class="profile-detail"><small>Faculty</small><b>${u.faculty || 'Not available'}</b></div>
      <div class="profile-detail"><small>Phone</small><b>${u.phone || 'Not available'}</b></div>
      <div class="profile-detail"><small>Username</small><b>${u.username || localStorage.getItem('username') || 'Not available'}</b></div>
    </div>
    <button class="primary" onclick="deleteAccount()">Delete Account</button>`;

  let all = [...(JSON.parse(localStorage.getItem('lostItems')) || []), ...(JSON.parse(localStorage.getItem('foundItems')) || [])]
    .filter(x => x.user === localStorage.getItem('username'));

  $('myItems').innerHTML = all.length
    ? all.map(x => `<div class="mini"><b>${x.name}</b><p>📍 ${x.location} · ${x.date}</p><span class="report-type ${x.type === 'found' ? 'found' : ''}">${x.type}</span></div>`).join('')
    : '<div class="empty">No reports yet. Start by reporting a lost or found item.</div>';
}

function deleteAccount() {
  if (confirm('Delete your account?')) {
    localStorage.removeItem('user');
    localStorage.removeItem('loggedIn');
    localStorage.removeItem('username');
    location.href = 'login.html';
  }
}

if ($('detail')) {
  let id = new URLSearchParams(location.search).get('id');
  let type = new URLSearchParams(location.search).get('type');
  let arr = JSON.parse(localStorage.getItem(type + 'Items')) || [];
  let x = arr.find(a => String(a.id) === id);

  if (!x) {
    $('detail').innerHTML = '<h2>Item not found.</h2>';
  } else {
    $('detail').innerHTML = `<img src="${x.image}" alt="${x.name}" onerror="this.onerror=null;this.src=makeItemImage(this.alt,'')">
      <div class="detail-info">
        <h1>${x.name}</h1>
        <p><b>Category:</b> ${x.category}</p>
        <p><b>Date:</b> ${x.date}</p>
        <p><b>Location:</b> ${x.location}</p>
        <p><b>Description:</b> ${x.description}</p>
        <p><b>Status:</b> ${x.type}</p>
        <p><b>Reported by:</b> ${x.user}</p>
        <p><b>Contact:</b> ${x.contact}</p>
        <a class="details-btn" href="tel:${x.contact}">${x.type === 'lost' ? 'Contact Owner' : 'Contact Reporter'}</a>
      </div>`;
  }
}

function togglePassword() {
  let input = $('loginPass');
  input.type = input.type === 'password' ? 'text' : 'password';
}


/* Live preview on report pages: image changes to match the typed item name */
if ($('itemName') && $('reportPreview')) {
  const upd = () => { $('reportPreview').src = makeItemImage($('itemName').value.trim() || 'Your item', $('itemCategory').value); };
  $('itemName').addEventListener('input', upd);
  $('itemImage').addEventListener('change', e => {
    const f = e.target.files[0];
    if (f) { const r = new FileReader(); r.onload = () => $('reportPreview').src = r.result; r.readAsDataURL(f); } else upd();
  });
  upd();
}
