const { useState, useEffect } = React;

function Header() {
  const [open, setOpen] = useState(false);
  const username = localStorage.getItem("username");

  function signOut(event) {
    event.preventDefault();
    localStorage.removeItem("loggedIn");
    localStorage.removeItem("username");
    window.location.href = "index.html";
  }

  return (
    <header className="header home-header">
      <div className="brand">
        <a className="logo" href="index.html">i<span>FOUND</span> 🔎</a>
        <div className="tagline">Never Lose Hope</div>
      </div>
      <button className="menu" aria-label="Toggle navigation" onClick={() => setOpen(!open)}>☰</button>
      <nav className={`nav ${open ? "open" : ""}`}>
        <a className="active" href="index.html">Home</a>
        <a href="lost.html">Lost items</a>
        <a href="found.html">Found items</a>
        <a href="report-lost.html">Report lost</a>
        <a href="report-found.html">Report found</a>
        {username ? <>
          <a href="profile.html">My profile</a>
          <a href="#" onClick={signOut}>Sign out</a>
        </> : <>
          <a href="login.html">Sign in</a>
          <a className="nav-cta" href="signup.html">Create account</a>
        </>}
      </nav>
    </header>
  );
}

function App() {
  const [stats, setStats] = useState({ lost: 5, found: 4 });

  useEffect(() => {
    try {
      const lost = JSON.parse(localStorage.getItem("lostItems") || "[]");
      const found = JSON.parse(localStorage.getItem("foundItems") || "[]");
      setStats({ lost: lost.length, found: found.length });
    } catch (error) {
      // Keep the sample statistics if saved data is unavailable.
    }

    const loader = document.getElementById("loading-screen");
    window.setTimeout(() => loader?.classList.add("loading-hidden"), 700);
  }, []);

  return <>
    <Header />
    <main>
      <section className="hero hero-react">
        <div className="hero-copy">
          <span className="eyebrow"><span className="eyebrow-dot"></span>A smarter campus community</span>
          <h1>Lost something?<br /><span className="green">Let's bring it home.</span></h1>
          <p className="hero-description">A notebook, keys, or something important — report it, search campus listings, and help belongings find their way back.</p>
          <div className="hero-actions">
            <a className="action lost-btn" href="lost.html">Find a lost item <span>↗</span></a>
            <a className="action found-btn" href="report-found.html">I found something <span>＋</span></a>
          </div>
          <div className="hero-trust"><span className="trust-icon">✓</span><span>Made for students, powered by community</span></div>
        </div>
        <div className="hero-visual">
          <div className="hero-photo-main">
            <img src="assets/images/backpack-ref.jpg" alt="Backpack reported as a lost item" fetchpriority="high" />
            <span className="photo-label">Lost item spotlight</span>
          </div>
          <div className="floating-item floating-watch">
            <img src="assets/images/watch-ref.jpg" alt="Watch" loading="eager" />
            <span><b>Watch</b><small>Found · Library</small></span><i>✓</i>
          </div>
          <div className="floating-item floating-keys">
            <img src="assets/images/keys-ref.jpg" alt="Keys" loading="eager" />
            <span><b>Set of keys</b><small>Found · Main gate</small></span><i>✓</i>
          </div>
          <div className="hero-orbit"></div>
        </div>
      </section>

      <section className="quick-stats">
        <div><strong>{stats.lost}</strong><span>Lost listings</span></div>
        <div><strong>{stats.found}</strong><span>Found listings</span></div>
        <div><strong>3</strong><span>Simple steps</span></div>
        <div className="stat-message"><span className="stat-heart">♥</span><span>Every return makes<br />campus a little kinder.</span></div>
      </section>

      <section className="home-section">
        <div className="section-heading">
          <div><span className="eyebrow">START HERE</span><h2>What brings you here today?</h2></div>
          <p>Choose a path and take the next step.</p>
        </div>
        <div className="choice-grid">
          <a className="choice-card lost-choice" href="lost.html">
            <div className="choice-icon">⌕</div><span className="choice-kicker">CAN'T FIND IT?</span>
            <h3>I've lost something</h3><p>Browse recent reports and see if someone has found your item.</p>
            <span className="choice-link">Browse lost items <b>→</b></span>
          </a>
          <a className="choice-card found-choice" href="found.html">
            <div className="choice-icon">✓</div><span className="choice-kicker">HELP IT GET HOME</span>
            <h3>I've found something</h3><p>Check existing reports or share details about an item you found.</p>
            <span className="choice-link">Browse found items <b>→</b></span>
          </a>
          <a className="choice-card report-choice" href="report-lost.html">
            <div className="choice-icon">＋</div><span className="choice-kicker">MAKE A REPORT</span>
            <h3>Post a listing</h3><p>Add a description, location, date and photo to help others identify it.</p>
            <span className="choice-link">Create a report <b>→</b></span>
          </a>
        </div>
      </section>

      <section className="how-section">
        <div className="how-visual">
          <img src="assets/images/notebook-ref.jpg" alt="Notebook on a desk" loading="lazy" />
          <div className="how-sticker"><span>✦</span><b>Small actions.<br />Happy reunions.</b></div>
        </div>
        <div className="how-copy">
          <span className="eyebrow">SIMPLE BY DESIGN</span><h2>Three steps.<br /><span className="green">One less worry.</span></h2>
          <div className="how-step"><span>01</span><div><h3>Report it</h3><p>Share the key details and a photo if you have one.</p></div></div>
          <div className="how-step"><span>02</span><div><h3>Search listings</h3><p>Use search and categories to narrow down matching items.</p></div></div>
          <div className="how-step"><span>03</span><div><h3>Reconnect</h3><p>Open an item listing and contact the reporter to coordinate a safe return.</p></div></div>
          <a className="text-link" href="report-lost.html">Make your first report <b>→</b></a>
        </div>
      </section>

      <section className="community-banner">
        <div><span className="eyebrow">LOOKING OUT FOR EACH OTHER</span><h2>That lost item might be<br />one search away.</h2><p>Start with the listings. If you don't see it, create a report so the community can help.</p></div>
        <div className="banner-actions"><a className="action banner-light" href="lost.html">Explore listings ↗</a><a className="banner-secondary" href="signup.html">Join iFOUND</a></div>
      </section>
    </main>

    <footer className="footer modern-footer">
      <div className="footer-brand"><a className="logo" href="index.html">i<span>FOUND</span> 🔎</a><p>Never lose hope. Find it, return it, reunite.</p></div>
      <div><h3>Explore</h3><a href="lost.html">Lost items</a><a href="found.html">Found items</a><a href="report-lost.html">Report lost</a><a href="report-found.html">Report found</a></div>
      <div><h3>Your account</h3><a href="login.html">Sign in</a><a href="signup.html">Create account</a><a href="profile.html">My profile</a></div>
      <div><h3>About iFOUND</h3><a href="#how-it-works" onClick={event => { event.preventDefault(); document.querySelector('.how-section').scrollIntoView({ behavior: 'smooth' }); }}>How it works</a><a href="mailto:support@ifound.example">Contact support</a><p className="footer-note">Demo project · Please don't post sensitive personal details.</p></div>
      <div className="copy">© 2026 iFOUND · Built to help campus communities reconnect with their belongings.</div>
    </footer>
  </>;
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
