/* Generates a matching illustration for any item name (wallet -> wallet picture, etc.) */
(function () {
  const G = '#228b22', D = '#145b3c', L = '#e8f8c9', W = '#fffdf5';
  const art = {
    wallet: `<rect x="190" y="125" width="320" height="200" rx="22" fill="#8a5a33"/><rect x="190" y="125" width="320" height="60" rx="22" fill="#a06a3c"/><rect x="420" y="205" width="110" height="64" rx="16" fill="#6b4226"/><circle cx="458" cy="237" r="9" fill="#e6c36a"/><path d="M215 165h250" stroke="#6b4226" stroke-width="4" stroke-dasharray="10 8"/>`,
    keys: `<circle cx="230" cy="215" r="58" fill="#ddb43b" stroke="#946f12" stroke-width="8"/><circle cx="230" cy="215" r="20" fill="${L}"/><rect x="285" y="198" width="270" height="34" fill="#ddb43b"/><rect x="450" y="232" width="34" height="48" fill="#ddb43b"/><rect x="510" y="232" width="34" height="38" fill="#ddb43b"/><circle cx="170" cy="150" r="20" fill="none" stroke="#777" stroke-width="7"/><rect x="150" y="165" width="40" height="30" rx="6" fill="${G}"/>`,
    calculator: `<rect x="255" y="55" width="190" height="290" rx="20" fill="#2c3338"/><rect x="275" y="78" width="150" height="55" rx="6" fill="#bfe3b4"/>${[0,1,2,3].map(r=>[0,1,2,3].map(c=>`<rect x="${277+c*38}" y="${150+r*44}" width="30" height="32" rx="6" fill="${r==3&&c==3?'#e45745':'#6b7780'}"/>`).join('')).join('')}`,
    usb: `<rect x="150" y="175" width="120" height="100" rx="8" fill="#c8cfd4" stroke="#8a949b" stroke-width="5"/><rect x="180" y="195" width="20" height="24" fill="#555"/><rect x="215" y="195" width="20" height="24" fill="#555"/><rect x="270" y="165" width="260" height="120" rx="22" fill="#2c3338"/><circle cx="500" cy="225" r="14" fill="#fffdf5"/><rect x="310" y="205" width="110" height="40" rx="8" fill="${G}"/>`,
    earphones: `<path d="M240 120c-80 40-60 140 0 150M460 120c80 40 60 140 0 150" fill="none" stroke="#999" stroke-width="0"/><path d="M240 130c0 90 90 120 110 40M460 130c0 90-90 120-110 40" fill="none" stroke="#e9e9e9" stroke-width="7"/><circle cx="240" cy="115" r="30" fill="#fff" stroke="#bbb" stroke-width="6"/><circle cx="460" cy="115" r="30" fill="#fff" stroke="#bbb" stroke-width="6"/><path d="M350 170c0 90 0 110-30 150" fill="none" stroke="#e9e9e9" stroke-width="7"/><rect x="300" y="310" width="40" height="26" rx="5" fill="#555"/>`,
    watch: `<rect x="300" y="40" width="100" height="370" rx="20" fill="#3a3f44"/><circle cx="350" cy="225" r="110" fill="#1e2226" stroke="#555" stroke-width="10"/><circle cx="350" cy="225" r="90" fill="#f4f4f0"/><path d="M350 225V160M350 225l45 25" stroke="#111" stroke-width="8" stroke-linecap="round"/><circle cx="350" cy="225" r="8" fill="#e45745"/>`,
    laptop: `<rect x="175" y="95" width="350" height="215" rx="14" fill="#9aa3a9"/><rect x="195" y="113" width="310" height="179" rx="6" fill="#dbe9e0"/><path d="M130 310h440l-30 38H160z" fill="#c4cbd0"/><circle cx="350" cy="203" r="26" fill="${G}"/>`,
    phone: `<rect x="270" y="45" width="160" height="320" rx="26" fill="#2c3338"/><rect x="284" y="75" width="132" height="255" rx="8" fill="#dbe9e0"/><circle cx="350" cy="350" r="8" fill="#777"/><rect x="330" y="55" width="40" height="6" rx="3" fill="#666"/><circle cx="350" cy="200" r="30" fill="${G}"/>`,
    backpack: `<path d="M290 110c0-55 120-55 120 0" fill="none" stroke="${D}" stroke-width="22"/><rect x="215" y="105" width="270" height="250" rx="60" fill="#3d6fa0"/><rect x="255" y="235" width="190" height="90" rx="20" fill="#2e557c"/><path d="M255 190h190" stroke="#1f3a57" stroke-width="8"/><rect x="330" y="255" width="40" height="22" rx="5" fill="#ddb43b"/>`,
    bottle: `<rect x="320" y="45" width="60" height="45" rx="8" fill="${D}"/><rect x="285" y="85" width="130" height="270" rx="40" fill="${G}"/><circle cx="350" cy="225" r="34" fill="${W}" opacity=".85"/><path d="M330 225h40M350 205v40" stroke="${G}" stroke-width="7"/>`,
    notebook: `<rect x="225" y="55" width="250" height="300" rx="10" fill="#c9965c"/>${[0,1,2,3,4,5,6,7].map(i=>`<circle cx="225" cy="${85+i*34}" r="9" fill="#444"/>`).join('')}<rect x="285" y="105" width="150" height="90" rx="6" fill="${W}"/><path d="M300 225h120M300 250h90" stroke="#8a5a33" stroke-width="6"/>`,
    id: `<rect x="150" y="105" width="400" height="245" rx="18" fill="${W}" stroke="#1f4e9c" stroke-width="8"/><rect x="150" y="105" width="400" height="55" rx="14" fill="#1f4e9c"/><circle cx="235" cy="240" r="38" fill="#c7d3e0"/><path d="M185 330c0-60 100-60 100 0z" fill="#c7d3e0"/><path d="M325 215h175M325 245h140M325 275h110" stroke="#777" stroke-width="9" stroke-linecap="round"/>`,
    glasses: `<circle cx="240" cy="225" r="85" fill="#cfe8f5" fill-opacity=".6" stroke="#111" stroke-width="14"/><circle cx="460" cy="225" r="85" fill="#cfe8f5" fill-opacity=".6" stroke="#111" stroke-width="14"/><path d="M325 215q25-22 50 0M155 215l-60-30M545 215l60-30" stroke="#111" stroke-width="14" fill="none" stroke-linecap="round"/>`,
    umbrella: `<path d="M120 235a230 190 0 0 1 460 0z" fill="${G}"/><path d="M350 235v120q0 35-35 35" fill="none" stroke="#333" stroke-width="12" stroke-linecap="round"/><path d="M350 55v30" stroke="#333" stroke-width="10"/>`,
    charger: `<rect x="260" y="140" width="130" height="130" rx="18" fill="#f2f2f2" stroke="#bbb" stroke-width="6"/><rect x="390" y="180" width="50" height="14" fill="#999"/><rect x="390" y="218" width="50" height="14" fill="#999"/><path d="M260 205c-60 0-60 90-120 90" fill="none" stroke="#f2f2f2" stroke-width="12"/>`,
    mouse: `<rect x="270" y="95" width="160" height="240" rx="80" fill="#555"/><path d="M350 95v100M270 195h160" stroke="#888" stroke-width="6"/>`,
    book: `<rect x="215" y="65" width="270" height="290" rx="10" fill="#3d6fa0"/><rect x="215" y="65" width="28" height="290" fill="#2e557c"/><rect x="275" y="115" width="160" height="70" rx="6" fill="${W}"/><path d="M275 225h160M275 250h110" stroke="${W}" stroke-width="7"/>`,
    bottle2: ''
  };
  const rules = [
    [/wallet|purse|cardholder/, 'wallet'], [/key/, 'keys'], [/calc/, 'calculator'], [/usb|pen ?drive|flash|pendrive/, 'usb'],
    [/earphone|earbud|airpod|headphone|\bbuds\b|headset|\bear ?pods?\b/, 'earphones'], [/watch/, 'watch'], [/laptop|macbook|computer/, 'laptop'],
    [/phone|mobile|iphone|tablet|ipad/, 'phone'], [/bag|pack|satchel/, 'backpack'], [/bottle|flask/, 'bottle'],
    [/note|diary|journal/, 'notebook'], [/\bid\b|card|licen|passport|document/, 'id'], [/glass|spec|sunglass/, 'glasses'],
    [/umbrella/, 'umbrella'], [/charger|cable|adapter|power ?bank/, 'charger'], [/mouse/, 'mouse'], [/book|textbook/, 'book']
  ];
  const esc = s => String(s).replace(/[&<>"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const photos = {calculator:'calculator-photo.jpg', keys:'keys-photo.jpg', usb:'usb-drive-photo.jpg', notebook:'notebook-photo.jpg', earphones:'earphones-photo.jpg'};
  window.makeItemImage = function (name, category) {
    const n = (name || '').toLowerCase();
    let key = (rules.find(r => r[0].test(n)) || [])[1];
    if (photos[key]) return 'assets/images/' + photos[key];
    let body = key ? art[key] : `<rect x="195" y="105" width="310" height="215" rx="20" fill="${W}" stroke="${G}" stroke-width="8"/><circle cx="350" cy="205" r="50" fill="none" stroke="${G}" stroke-width="14"/><path d="M388 243l45 45" stroke="${G}" stroke-width="14" stroke-linecap="round"/>`;
    const label = esc((name || category || 'Item').trim().slice(0, 24).toUpperCase());
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 700 450"><rect width="700" height="450" fill="${L}"/>${body}<text x="350" y="415" text-anchor="middle" font-family="Arial,sans-serif" font-weight="bold" font-size="30" fill="${D}">${label}</text></svg>`;
    return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
  };
})();
