# iFOUND — Campus Lost & Found

A beginner-friendly lost-and-found website with a React-powered homepage and HTML/CSS/JavaScript pages for listings, reports, item details, sign-up, sign-in, and profile.

## Run the project
1. Extract the ZIP folder.
2. Open the `iFOUND` folder in VS Code.
3. Use the **Live Server** extension and open `index.html` (recommended). The React homepage loads React/Babel from a CDN, so an internet connection is required for that page.
4. Create an account on **Sign up**, then use that username and password on **Sign in**.

## Features
- React homepage with responsive layout, campus item photos, calls to action, stats, and three-step guide.
- Working navigation, mobile menu, sign-up validation, sign-in credential checking, and demo password reset.
- Search/filter for lost and found items; item detail pages; report forms with optional photo upload; profile and sign-out.
- Data is stored in this browser using `localStorage`.

## Important demo limitation
This is a front-end learning project, not a production authentication service. Passwords and reports are stored in browser `localStorage`, so they are not securely protected or shared across devices/browsers. The password reset is a local demo and does not send email. Do not use real passwords or publish private contact details. A real deployment needs a backend, secure password hashing, database, and verified account recovery.

## Main files
- `index.html` + `js/home.jsx`: React homepage
- `css/style.css`: shared styling and homepage refresh
- `js/script.js`: navigation, auth demo, reports, search, profile, and item details
- `assets/images/`: item photos and illustrations


## Latest homepage updates
- Restored the branded loading screen; it fades away when the React homepage mounts.
- Improved homepage photo sharpness and loading priority.
- Formatted the React homepage code for easy reading while keeping it compact.
- The original pale-green, cream, red-lost, and green-found theme is unchanged.


## Small updates
- Removed the confirm-password field; sign-up now asks for a password once (minimum 6 characters).
- Added a water-bottle item image and demo listing. Listing photos use a fallback image if a file is missing.
